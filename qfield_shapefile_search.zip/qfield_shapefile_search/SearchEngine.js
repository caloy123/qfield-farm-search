// =============================================================================
// SearchEngine.js - Core search and spatial logic for QField Shapefile Search
// Compatible with QField 3.x+ (QML / QtQuick / JavaScript engine)
// =============================================================================

.pragma library

/**
 * Checks if a layer is a vector layer
 */
function isVectorLayer(layer) {
    if (!layer) return false;
    try {
        if (typeof layer.type === 'function') {
            return layer.type() === 0; // 0 = QgsMapLayerType::VectorLayer
        }
        if (typeof layer.type !== 'undefined') {
            return layer.type === 0 || layer.type === "VectorLayer";
        }
        // Fallback: check if layer has getFeatures or fields
        return typeof layer.getFeatures === 'function' || typeof layer.fields !== 'undefined';
    } catch (e) {
        return false;
    }
}

/**
 * Returns all vector layers loaded in the given QgsProject
 */
function getVectorLayers(project) {
    var layers = [];
    if (!project) return layers;

    try {
        var mapLayers = (typeof project.mapLayers === 'function') ? project.mapLayers() : project.mapLayers;
        if (mapLayers) {
            for (var key in mapLayers) {
                var layer = mapLayers[key];
                if (layer && isVectorLayer(layer)) {
                    var name = (typeof layer.name === 'function') ? layer.name() : (layer.name || key);
                    var id = (typeof layer.id === 'function') ? layer.id() : (layer.id || key);
                    layers.push({
                        id: id,
                        name: name,
                        layer: layer
                    });
                }
            }
        }
    } catch (e) {
        console.log("[SearchEngine] Error getting vector layers: " + e);
    }

    // Sort alphabetically by layer name
    layers.sort(function(a, b) {
        return a.name.localeCompare(b.name);
    });

    return layers;
}

/**
 * Returns an array of field names for the given layer
 */
function getLayerFields(layer) {
    var fieldNames = [];
    if (!layer) return fieldNames;

    try {
        var fields = (typeof layer.fields === 'function') ? layer.fields() : layer.fields;
        if (fields) {
            if (typeof fields.names === 'function') {
                return fields.names();
            }
            var count = (typeof fields.count === 'function') ? fields.count() : fields.count;
            if (typeof count === 'number') {
                for (var i = 0; i < count; i++) {
                    var f = (typeof fields.at === 'function') ? fields.at(i) : (typeof fields.field === 'function' ? fields.field(i) : null);
                    if (f) {
                        var fname = (typeof f.name === 'function') ? f.name() : f.name;
                        if (fname) fieldNames.push(fname);
                    }
                }
            }
        }
    } catch (e) {
        console.log("[SearchEngine] Error getting layer fields: " + e);
    }

    return fieldNames;
}

/**
 * Escape single quotes for QGIS expression strings
 */
function escapeSqlString(text) {
    if (!text) return "";
    return ("" + text).replace(/'/g, "''");
}

/**
 * Builds a single field comparison expression string
 */
function buildFieldExpression(fieldName, searchText, matchMode, caseSensitive) {
    if (!fieldName || !searchText) return "";

    var safeField = '"' + fieldName.replace(/"/g, '""') + '"';
    var text = searchText.trim();
    var escaped = escapeSqlString(text);

    // Range mode: min,max
    if (matchMode === "range") {
        var parts = text.split(",");
        if (parts.length === 2) {
            var lo = parseFloat(parts[0].trim());
            var hi = parseFloat(parts[1].trim());
            if (!isNaN(lo) && !isNaN(hi)) {
                return "to_real(" + safeField + ") >= " + lo + " AND to_real(" + safeField + ") <= " + hi;
            }
        }
        return "";
    }

    // Exact mode
    if (matchMode === "exact") {
        var num = parseFloat(text);
        if (!isNaN(num) && ("" + num) === text) {
            return safeField + " = " + num;
        }
        if (caseSensitive) {
            return "to_string(" + safeField + ") = '" + escaped + "'";
        } else {
            return "lower(to_string(" + safeField + ")) = lower('" + escaped + "')";
        }
    }

    // Wildcard mode
    if (matchMode === "wildcard") {
        var pattern = escaped.replace(/\*/g, "%").replace(/\?/g, "_");
        if (caseSensitive) {
            return "to_string(" + safeField + ") LIKE '" + pattern + "'";
        } else {
            return "to_string(" + safeField + ") ILIKE '" + pattern + "'";
        }
    }

    // Starts with mode
    if (matchMode === "starts") {
        if (caseSensitive) {
            return "to_string(" + safeField + ") LIKE '" + escaped + "%'";
        } else {
            return "to_string(" + safeField + ") ILIKE '" + escaped + "%'";
        }
    }

    // Ends with mode
    if (matchMode === "ends") {
        if (caseSensitive) {
            return "to_string(" + safeField + ") LIKE '%" + escaped + "'";
        } else {
            return "to_string(" + safeField + ") ILIKE '%" + escaped + "'";
        }
    }

    // Contains mode (default)
    if (caseSensitive) {
        return "to_string(" + safeField + ") LIKE '%" + escaped + "%'";
    } else {
        return "to_string(" + safeField + ") ILIKE '%" + escaped + "%'";
    }
}

/**
 * Builds the complete expression string for a layer across specified fields
 */
function buildLayerExpression(fieldNames, searchText, matchMode, caseSensitive) {
    if (!fieldNames || fieldNames.length === 0 || !searchText) return "";

    var clauses = [];
    for (var i = 0; i < fieldNames.length; i++) {
        var clause = buildFieldExpression(fieldNames[i], searchText, matchMode, caseSensitive);
        if (clause) {
            clauses.push("(" + clause + ")");
        }
    }

    if (clauses.length === 0) return "";
    return clauses.join(" OR ");
}

/**
 * Extracts attributes map from a feature
 */
function extractAttributes(feature, layer) {
    var attrs = {};
    if (!feature) return attrs;

    try {
        var fieldNames = getLayerFields(layer);
        if (fieldNames.length > 0) {
            for (var i = 0; i < fieldNames.length; i++) {
                var fname = fieldNames[i];
                var val = null;
                if (typeof feature.attribute === 'function') {
                    val = feature.attribute(fname);
                } else if (feature.attributes) {
                    var all = (typeof feature.attributes === 'function') ? feature.attributes() : feature.attributes;
                    if (all && typeof all[i] !== 'undefined') {
                        val = all[i];
                    }
                }
                attrs[fname] = (val !== null && typeof val !== 'undefined') ? ("" + val) : "";
            }
        }
    } catch (e) {
        console.log("[SearchEngine] Attribute extraction error: " + e);
    }

    return attrs;
}

/**
 * Searches a single vector layer using QField's LayerUtils or feature iterator
 */
function searchLayer(layer, fieldNames, searchText, matchMode, caseSensitive, maxResults, layerUtils) {
    var results = [];
    if (!layer || !searchText || !fieldNames || fieldNames.length === 0) return results;

    var exprString = buildLayerExpression(fieldNames, searchText, matchMode, caseSensitive);
    if (!exprString) return results;

    var layerName = (typeof layer.name === 'function') ? layer.name() : (layer.name || "Layer");
    var layerId = (typeof layer.id === 'function') ? layer.id() : (layer.id || "");

    var iterator = null;
    try {
        // Method 1: Using QField's LayerUtils
        if (layerUtils && typeof layerUtils.createFeatureIteratorFromExpression === 'function') {
            iterator = layerUtils.createFeatureIteratorFromExpression(layer, exprString);
        }
        // Method 2: Fallback to layer.getFeatures
        else if (typeof layer.getFeatures === 'function') {
            iterator = layer.getFeatures(exprString);
        }

        if (iterator) {
            var count = 0;
            while (count < maxResults) {
                var feat = null;
                if (typeof iterator.hasNext === 'function') {
                    if (!iterator.hasNext()) break;
                    feat = iterator.next();
                } else if (typeof iterator.nextFeature === 'function') {
                    feat = (typeof layer.createFeature === 'function') ? layer.createFeature() : {};
                    if (!iterator.nextFeature(feat)) break;
                } else {
                    break;
                }

                if (feat) {
                    var fid = (typeof feat.id === 'function') ? feat.id() : (feat.id || count);
                    var attrs = extractAttributes(feat, layer);
                    
                    // Determine display title & subtitle
                    var title = "FID: " + fid;
                    var subtitle = "";
                    for (var fn in attrs) {
                        if (attrs[fn] && fn.toLowerCase().match(/(name|label|title|code|desc|id|farm|parcel|owner)/i)) {
                            title = attrs[fn];
                            break;
                        }
                    }
                    
                    var snippets = [];
                    for (var fn2 in attrs) {
                        if (attrs[fn2] && attrs[fn2] !== title) {
                            snippets.push(fn2 + ": " + attrs[fn2]);
                            if (snippets.length >= 2) break;
                        }
                    }
                    subtitle = snippets.join(" | ");

                    results.push({
                        fid: fid,
                        layerId: layerId,
                        layerName: layerName,
                        layer: layer,
                        feature: feat,
                        title: title,
                        subtitle: subtitle,
                        attributes: attrs
                    });
                    count++;
                }
            }
        }
    } catch (e) {
        console.log("[SearchEngine] Search error on layer " + layerName + ": " + e);
    } finally {
        if (iterator && typeof iterator.close === 'function') {
            try { iterator.close(); } catch (e) {}
        }
    }

    return results;
}

/**
 * Searches across multiple vector layers
 */
function searchAllLayers(layers, fieldFilter, searchText, matchMode, caseSensitive, maxResults, layerUtils) {
    var allResults = [];
    var remaining = maxResults || 100;

    for (var i = 0; i < layers.length; i++) {
        if (remaining <= 0) break;
        var lyr = layers[i].layer || layers[i];
        var availableFields = getLayerFields(lyr);

        var searchFields = availableFields;
        if (fieldFilter && fieldFilter.length > 0 && fieldFilter !== "ALL") {
            searchFields = availableFields.filter(function(f) {
                return f.toLowerCase() === fieldFilter.toLowerCase();
            });
        }

        if (searchFields.length > 0) {
            var layerResults = searchLayer(lyr, searchFields, searchText, matchMode, caseSensitive, remaining, layerUtils);
            allResults = allResults.concat(layerResults);
            remaining -= layerResults.length;
        }
    }

    return allResults;
}

/**
 * Zooms and centers the map canvas to the feature's geometry
 */
function zoomToFeature(feature, layer, mapCanvas, project, geomUtils, crsUtils) {
    if (!feature || !mapCanvas) return false;

    try {
        var geom = (typeof feature.geometry === 'function') ? feature.geometry() : feature.geometry;
        if (!geom) return false;

        var isNull = (typeof geom.isNull === 'function') ? geom.isNull() : false;
        var isEmpty = (typeof geom.isEmpty === 'function') ? geom.isEmpty() : false;
        if (isNull || isEmpty) return false;

        var box = (typeof geom.boundingBox === 'function') ? geom.boundingBox() : null;
        if (!box) return false;

        // Reproject box if layer CRS differs from project CRS
        var layerCrs = (layer && layer.crs) ? (typeof layer.crs === 'function' ? layer.crs() : layer.crs) : null;
        var projectCrs = (project && project.crs) ? project.crs : null;

        var targetBox = box;
        if (geomUtils && crsUtils && layerCrs && projectCrs) {
            try {
                if (typeof geomUtils.reprojectRectangle === 'function') {
                    targetBox = geomUtils.reprojectRectangle(box, layerCrs, projectCrs);
                }
            } catch (e) {
                targetBox = box;
            }
        }

        // Apply to map canvas
        if (mapCanvas.mapSettings) {
            var width = (typeof targetBox.width === 'function') ? targetBox.width() : targetBox.width;
            var height = (typeof targetBox.height === 'function') ? targetBox.height() : targetBox.height;

            // If point geometry (extent is zero), jump to point with fixed scale
            if (width === 0 && height === 0) {
                var center = (typeof geom.centroid === 'function') ? geom.centroid().asPoint() : null;
                if (center) {
                    if (geomUtils && crsUtils && layerCrs && projectCrs && typeof geomUtils.reprojectPoint === 'function') {
                        try {
                            center = geomUtils.reprojectPoint(center, layerCrs, projectCrs);
                        } catch (e) {}
                    }
                    if (typeof mapCanvas.jumpTo === 'function') {
                        mapCanvas.jumpTo(center, 2500);
                    } else {
                        mapCanvas.mapSettings.center = center;
                    }
                    return true;
                }
            }

            // Polygon / Line extent: set extent with small buffer
            if (typeof mapCanvas.setExtent === 'function') {
                mapCanvas.setExtent(targetBox);
            } else if (mapCanvas.mapSettings) {
                mapCanvas.mapSettings.extent = targetBox;
            }
            return true;
        }
    } catch (e) {
        console.log("[SearchEngine] Zoom error: " + e);
    }

    return false;
}

/**
 * Formats results into a GeoJSON FeatureCollection string
 */
function exportToGeoJson(results) {
    var features = [];
    for (var i = 0; i < results.length; i++) {
        var r = results[i];
        var featObj = {
            type: "Feature",
            id: r.fid,
            properties: {
                _layer: r.layerName,
                _fid: r.fid
            }
        };
        for (var k in r.attributes) {
            featObj.properties[k] = r.attributes[k];
        }
        features.push(featObj);
    }

    return JSON.stringify({
        type: "FeatureCollection",
        count: features.length,
        features: features
    }, null, 2);
}

/**
 * Formats results into a CSV string
 */
function exportToCsv(results) {
    if (!results || results.length === 0) return "";

    // Collect all unique field keys
    var fieldSet = {};
    for (var i = 0; i < results.length; i++) {
        for (var k in results[i].attributes) {
            fieldSet[k] = true;
        }
    }
    var headers = ["Layer", "FID"].concat(Object.keys(fieldSet));

    var lines = [headers.join(",")];
    for (var j = 0; j < results.length; j++) {
        var res = results[j];
        var row = [
            '"' + (res.layerName || "").replace(/"/g, '""') + '"',
            res.fid
        ];
        for (var h = 2; h < headers.length; h++) {
            var val = res.attributes[headers[h]] || "";
            row.push('"' + ("" + val).replace(/"/g, '""') + '"');
        }
        lines.push(row.join(","));
    }

    return lines.join("\n");
}
