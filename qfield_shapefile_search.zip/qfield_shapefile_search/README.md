# Shapefile & Vector Search for QField

A native, mobile-optimized search and query plugin for the **QField** mobile application (Android, iOS, Windows, macOS, Linux).

Adapted directly from the desktop **Shapefile Search (v2.0.0)** plugin, re-engineered specifically for QField's **QML and JavaScript** runtime.

---

## 📱 Why a Dedicated QField Plugin?

The reference desktop plugin (`shapefile_search_improved`) is built in **Python / PyQt5** for desktop QGIS. Because QField runs on mobile operating systems (Android, iOS) with touch interfaces, **QField does not support Python plugins**; it requires **QML and JavaScript** plugins.

This plugin ports all core features into QField's native touch environment:
- 🔍 **Multi-layer Search:** Search across all loaded vector layers (Shapefiles, GeoPackage, GeoJSON, SpatiaLite, etc.) or a specific layer.
- 🎯 **Field Filtering:** Search all fields or restrict queries to a specific attribute column.
- ⚙️ **Rich Search Modes:**
  - **Contains:** Case-insensitive substring match (e.g., `iloilo` matches `Iloilo City`).
  - **Exact Match:** Exact string or numeric equality.
  - **Starts With / Ends With:** Prefix or suffix matching.
  - **Wildcard (`*`, `?`):** Glob search (e.g., `Farm*2024`).
  - **Numeric Range:** Min/Max filtering (e.g., `100, 500`).
- 📍 **One-Touch Zoom & Pan:** Tap any search result to automatically pan, center, and zoom the map canvas directly to the feature's geometry (with CRS reprojection).
- 📋 **Attribute Inspector:** Touch-friendly card view showing all attribute field-value pairs for matched features.
- 📤 **GeoJSON / Clipboard Copy:** One-tap export to copy matched features and attributes to the clipboard.

---

## 🚀 Installation & Deployment Methods

You can deploy this plugin in two ways:

### Option 1: App-Wide Plugin (.zip Archive)
*(Installs globally in QField across all projects)*

1. Copy `qfield_shapefile_search_v1.0.0.zip` to your mobile device or desktop.
2. In QField:
   - Go to **Settings (gear icon) > Plugins**.
   - Tap **Import plugin from archive (.zip)**.
   - Select `qfield_shapefile_search_v1.0.0.zip`.
3. The plugin will be enabled. When you open any project with vector layers, the **Shapefile Search** icon will appear on the plugins toolbar.

#### Manual Directory Installation (Alternative):
Extract the zip contents into the QField plugins directory:
- **Android:** `/Android/data/ch.opengis.qfield/files/plugins/qfield_shapefile_search/`
- **Windows:** `%APPDATA%\QField\plugins\qfield_shapefile_search\`
- **Linux:** `~/.local/share/QField/plugins/qfield_shapefile_search/`
- **macOS:** `~/Library/Application Support/QField/plugins/qfield_shapefile_search/`

---

### Option 2: Project Sidecar Plugin (Zero-Install / QFieldCloud)
*(Recommended for field teams syncing via QFieldCloud)*

QField automatically loads `.qml` sidecar files matching the project filename:
1. Locate your QGIS project file (e.g., `my_field_project.qgz` or `my_field_project.qgs`).
2. Take the provided file `project_sidecar_template.qml` and rename it to match your project name exactly:
   ```
   my_field_project.qgz
   my_field_project.qml   <-- Renamed sidecar
   ```
3. Place `my_field_project.qml` in the exact same folder as your `.qgz` project.
4. When synced via **QFieldCloud** or opened in QField, the search tool button is automatically loaded with zero manual installation required on field devices!

---

## 📖 How to Use

1. **Open the Tool:** Tap the 🔍 icon in the QField toolbar.
2. **Select Target Layer:** Choose **"All Vector Layers"** or pick a specific loaded layer.
3. **Select Field:** Leave as **"All Fields"** or choose a specific attribute column.
4. **Choose Mode:** Select `Contains`, `Exact`, `Starts With`, `Wildcard`, or `Numeric Range`.
5. **Enter Search Value:** Type your search text in the input box and tap **🔍 Search**.
6. **Navigate Results:**
   - Tap any result card to **zoom and center the map** to that feature.
   - Tap **📋 (Inspect)** to view all attributes for that feature in a clean table.
   - Tap **📋 Copy All** to copy all matching features as standard GeoJSON to share or save.

---

## 📁 Package Structure

```
qfield_shapefile_search/
├── metadata.txt                  # QField plugin manifest
├── icon.svg                      # High-res SVG plugin toolbar icon
├── main.qml                      # Main QML application entry point
├── SearchEngine.js               # Core search, filtering, and geometry engine
├── project_sidecar_template.qml  # Single-file sidecar template for QFieldCloud
└── README.md                     # Documentation and deployment guide
```

---

## 🛠 Compatibility
- **QField:** 3.0.0 and above
- **Platforms:** Android, iOS, Windows, macOS, Linux
- **Vector Formats:** Shapefile (.shp), GeoPackage (.gpkg), GeoJSON, SpatiaLite, KML, PostGIS
