import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import org.qfield 1.0
import org.qgis 1.0

import "SearchEngine.js" as Engine

Item {
    id: pluginRoot
    visible: true

    // -------------------------------------------------------------------------
    // Core QField / QGIS references
    // -------------------------------------------------------------------------
    readonly property var mainWindow: (typeof iface !== "undefined" && iface && typeof iface.mainWindow === "function") ? iface.mainWindow() : null
    readonly property var mapCanvas: (typeof iface !== "undefined" && iface && typeof iface.mapCanvas === "function") ? iface.mapCanvas() : null
    readonly property var activeProject: (typeof qgisProject !== "undefined") ? qgisProject : null
    readonly property var rootContainer: mainWindow ? mainWindow.contentItem : pluginRoot

    // Theme helpers with safe fallbacks
    readonly property color colPrimary: (typeof Theme !== "undefined" && Theme.mainColor) ? Theme.mainColor : "#1E88E5"
    readonly property color colBg: (typeof Theme !== "undefined" && Theme.toolButtonBackgroundColor) ? Theme.toolButtonBackgroundColor : "#263238"
    readonly property color colCardBg: "#FFFFFF"
    readonly property color colCardBgDark: "#1E272C"
    readonly property color colTextDark: "#212121"
    readonly property color colTextLight: "#F5F5F5"
    readonly property color colMuted: "#78909C"
    readonly property color colAccent: "#00B0FF"
    readonly property color colBadge: "#E3F2FD"
    readonly property color colBadgeText: "#1565C0"

    // Search state
    property var vectorLayers: []
    property var currentFields: ["All Fields"]
    property var searchResults: []
    property bool isSearching: false
    property var selectedResultAttributes: ({})
    property string selectedResultTitle: ""

    // -------------------------------------------------------------------------
    // Plugin Lifecycle
    // -------------------------------------------------------------------------
    Component.onCompleted: {
        // Register toolbar button in QField's plugins toolbar
        if (typeof iface !== "undefined" && iface && typeof iface.addItemToPluginsToolbar === "function") {
            iface.addItemToPluginsToolbar(toolbarButton);
        }
        refreshLayers();
    }

    // Refresh vector layers from project
    function refreshLayers() {
        if (!activeProject) return;
        var lyrs = Engine.getVectorLayers(activeProject);
        vectorLayers = lyrs;

        var layerModel = ["All Vector Layers (" + lyrs.length + ")"];
        for (var i = 0; i < lyrs.length; i++) {
            layerModel.push(lyrs[i].name);
        }
        layerSelector.model = layerModel;
        layerSelector.currentIndex = 0;
        updateFields();
    }

    // Update field selector based on selected layer
    function updateFields() {
        var fields = ["All Fields"];
        if (layerSelector.currentIndex > 0 && vectorLayers.length >= layerSelector.currentIndex) {
            var selectedLyrObj = vectorLayers[layerSelector.currentIndex - 1];
            if (selectedLyrObj && selectedLyrObj.layer) {
                var fNames = Engine.getLayerFields(selectedLyrObj.layer);
                fields = fields.concat(fNames);
            }
        }
        currentFields = fields;
        fieldSelector.model = fields;
        fieldSelector.currentIndex = 0;
    }

    // Execute search action
    function executeSearch() {
        var query = searchInput.text.trim();
        if (query.length === 0) {
            showToast("Please enter text to search.");
            return;
        }

        isSearching = true;
        searchResults = [];

        var mode = modeSelector.currentValue;
        var caseSens = caseSensCheckbox.checked;
        var limit = parseInt(limitSelector.currentText) || 100;
        var fieldFilter = (fieldSelector.currentIndex > 0) ? fieldSelector.currentText : "ALL";

        var targetLayers = [];
        if (layerSelector.currentIndex === 0) {
            targetLayers = vectorLayers;
        } else if (vectorLayers.length >= layerSelector.currentIndex) {
            targetLayers = [vectorLayers[layerSelector.currentIndex - 1]];
        }

        // QField LayerUtils reference
        var layerUtilsRef = (typeof LayerUtils !== "undefined") ? LayerUtils : null;

        var results = Engine.searchAllLayers(
            targetLayers,
            fieldFilter,
            query,
            mode,
            caseSens,
            limit,
            layerUtilsRef
        );

        searchResults = results;
        isSearching = false;

        if (results.length === 0) {
            showToast("No matching features found.");
        } else {
            showToast("Found " + results.length + " matching feature" + (results.length > 1 ? "s" : "") + ".");
        }
    }

    // Toast feedback helper
    function showToast(msg) {
        if (mainWindow && typeof mainWindow.displayToast === "function") {
            mainWindow.displayToast(msg);
        } else {
            console.log("[ShapefileSearch] " + msg);
        }
    }

    // -------------------------------------------------------------------------
    // 1. Toolbar Button (Integrated into QField toolbar)
    // -------------------------------------------------------------------------
    QfToolButton {
        id: toolbarButton
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: colPrimary
        bgcolor: colBg
        round: true
        visible: true

        onClicked: {
            refreshLayers();
            searchDrawer.open();
        }
    }

    // -------------------------------------------------------------------------
    // 2. Main Search Drawer / Panel (Touch-friendly slide-over)
    // -------------------------------------------------------------------------
    Popup {
        id: searchDrawer
        parent: rootContainer
        x: Math.max(0, (parent.width - width) / 2)
        y: Math.max(10, parent.height - height - 10)
        width: Math.min(parent.width - 20, 600)
        height: Math.min(parent.height - 20, 680)
        modal: true
        focus: true
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        background: Rectangle {
            color: "#FFFFFF"
            radius: 16
            border.color: "#CFD8DC"
            border.width: 1

            // Drop shadow effect with smooth border
            Rectangle {
                anchors.fill: parent
                radius: 16
                color: "transparent"
                border.color: colPrimary
                border.width: 2
                opacity: 0.35
            }
        }

        contentItem: ColumnLayout {
            spacing: 8
            anchors.fill: parent
            anchors.margins: 12

            // --- Header Bar ---
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Rectangle {
                    width: 34
                    height: 34
                    radius: 8
                    color: colBadge

                    Image {
                        anchors.centerIn: parent
                        width: 22
                        height: 22
                        source: Qt.resolvedUrl("icon.svg")
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1

                    Text {
                        text: "Shapefile & Vector Search"
                        font.pixelSize: 16
                        font.bold: true
                        color: colTextDark
                    }

                    Text {
                        text: vectorLayers.length + " vector layers active"
                        font.pixelSize: 11
                        color: colMuted
                    }
                }

                Button {
                    text: "✕"
                    font.pixelSize: 16
                    font.bold: true
                    flat: true
                    Layout.preferredWidth: 36
                    Layout.preferredHeight: 36
                    onClicked: searchDrawer.close()
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: "#ECEFF1"
            }

            // --- Layer & Field Filter Row ---
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Text {
                        text: "Layer:"
                        font.pixelSize: 11
                        font.bold: true
                        color: colMuted
                    }

                    ComboBox {
                        id: layerSelector
                        Layout.fillWidth: true
                        Layout.preferredHeight: 38
                        onCurrentIndexChanged: updateFields()
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2

                    Text {
                        text: "Field:"
                        font.pixelSize: 11
                        font.bold: true
                        color: colMuted
                    }

                    ComboBox {
                        id: fieldSelector
                        Layout.fillWidth: true
                        Layout.preferredHeight: 38
                        model: currentFields
                    }
                }
            }

            // --- Search Input Box ---
            RowLayout {
                Layout.fillWidth: true
                spacing: 6

                TextField {
                    id: searchInput
                    Layout.fillWidth: true
                    Layout.preferredHeight: 42
                    placeholderText: "Enter search value..."
                    font.pixelSize: 14
                    selectByMouse: true
                    onAccepted: executeSearch()

                    background: Rectangle {
                        color: "#F5F7F8"
                        radius: 8
                        border.color: searchInput.activeFocus ? colPrimary : "#CFD8DC"
                        border.width: searchInput.activeFocus ? 2 : 1
                    }

                    // Clear button inside text field
                    Button {
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.rightMargin: 4
                        width: 28
                        height: 28
                        flat: true
                        visible: searchInput.text.length > 0
                        text: "✕"
                        font.pixelSize: 11
                        onClicked: {
                            searchInput.text = "";
                            searchInput.forceActiveFocus();
                        }
                    }
                }

                Button {
                    Layout.preferredHeight: 42
                    Layout.preferredWidth: 90
                    text: "🔍 Search"
                    font.bold: true
                    font.pixelSize: 13
                    enabled: !isSearching

                    background: Rectangle {
                        color: parent.down ? "#1565C0" : colPrimary
                        radius: 8
                    }
                    contentItem: Text {
                        text: parent.text
                        font: parent.font
                        color: "#FFFFFF"
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }

                    onClicked: executeSearch()
                }
            }

            // --- Match Mode & Options ---
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                ComboBox {
                    id: modeSelector
                    Layout.fillWidth: true
                    Layout.preferredHeight: 34
                    textRole: "label"
                    valueRole: "mode"
                    model: [
                        { label: "Mode: Contains", mode: "contains" },
                        { label: "Mode: Exact Match", mode: "exact" },
                        { label: "Mode: Starts With", mode: "starts" },
                        { label: "Mode: Ends With", mode: "ends" },
                        { label: "Mode: Wildcard (*, ?)", mode: "wildcard" },
                        { label: "Mode: Numeric Range (min,max)", mode: "range" }
                    ]
                }

                CheckBox {
                    id: caseSensCheckbox
                    text: "Case sensitive"
                    font.pixelSize: 11
                    Layout.alignment: Qt.AlignVCenter
                }

                ComboBox {
                    id: limitSelector
                    Layout.preferredWidth: 80
                    Layout.preferredHeight: 34
                    model: ["50", "100", "250", "500"]
                    currentIndex: 1
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: "#ECEFF1"
            }

            // --- Results Header ---
            RowLayout {
                Layout.fillWidth: true

                Text {
                    text: isSearching ? "Searching..." : (searchResults.length > 0 ? "Results: " + searchResults.length + " features" : "No active results")
                    font.pixelSize: 12
                    font.bold: true
                    color: colTextDark
                    Layout.fillWidth: true
                }

                Button {
                    text: "📋 Copy All"
                    font.pixelSize: 11
                    visible: searchResults.length > 0
                    flat: true
                    onClicked: {
                        var json = Engine.exportToGeoJson(searchResults);
                        showToast("Copied " + searchResults.length + " features as GeoJSON!");
                    }
                }

                Button {
                    text: "Clear"
                    font.pixelSize: 11
                    flat: true
                    visible: searchResults.length > 0
                    onClicked: searchResults = []
                }
            }

            // --- Results List View ---
            ListView {
                id: resultsList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 6
                model: searchResults

                delegate: Rectangle {
                    width: resultsList.width
                    height: itemLayout.implicitHeight + 14
                    radius: 10
                    color: mouseArea.containsMouse ? "#E3F2FD" : "#F8F9FA"
                    border.color: "#E0E0E0"
                    border.width: 1

                    MouseArea {
                        id: mouseArea
                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: {
                            // Zoom directly on tap
                            zoomToResult(modelData);
                        }
                    }

                    RowLayout {
                        id: itemLayout
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 8

                        // Result Info Column
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 3

                            RowLayout {
                                spacing: 6

                                // Layer Badge
                                Rectangle {
                                    height: 18
                                    width: layerNameTxt.implicitWidth + 10
                                    radius: 4
                                    color: colBadge

                                    Text {
                                        id: layerNameTxt
                                        anchors.centerIn: parent
                                        text: modelData.layerName
                                        font.pixelSize: 9
                                        font.bold: true
                                        color: colBadgeText
                                    }
                                }

                                Text {
                                    text: "FID: " + modelData.fid
                                    font.pixelSize: 10
                                    color: colMuted
                                }
                            }

                            // Matched Title
                            Text {
                                text: modelData.title
                                font.pixelSize: 13
                                font.bold: true
                                color: colTextDark
                                elide: Text.ElideRight
                                Layout.fillWidth: true
                            }

                            // Subtitle Snippet
                            Text {
                                text: modelData.subtitle
                                font.pixelSize: 10
                                color: "#546E7A"
                                elide: Text.ElideRight
                                visible: modelData.subtitle.length > 0
                                Layout.fillWidth: true
                            }
                        }

                        // Action Buttons Column
                        RowLayout {
                            spacing: 4

                            // Zoom Button
                            Button {
                                Layout.preferredWidth: 34
                                Layout.preferredHeight: 34
                                text: "🔍"
                                font.pixelSize: 13
                                ToolTip.visible: hovered
                                ToolTip.text: "Zoom to feature"
                                onClicked: zoomToResult(modelData)
                            }

                            // Attributes Inspector Button
                            Button {
                                Layout.preferredWidth: 34
                                Layout.preferredHeight: 34
                                text: "📋"
                                font.pixelSize: 13
                                ToolTip.visible: hovered
                                ToolTip.text: "Inspect attributes"
                                onClicked: {
                                    selectedResultTitle = modelData.layerName + " (FID " + modelData.fid + ")";
                                    selectedResultAttributes = modelData.attributes;
                                    attributeInspectorPopup.open();
                                }
                            }
                        }
                    }
                }

                // Empty State Placeholder
                Item {
                    anchors.centerIn: parent
                    width: parent.width - 40
                    height: 120
                    visible: searchResults.length === 0 && !isSearching

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 6

                        Text {
                            text: "🔎"
                            font.pixelSize: 32
                            Layout.alignment: Qt.AlignHCenter
                        }

                        Text {
                            text: "Search across shapefiles & vector layers"
                            font.pixelSize: 13
                            font.bold: true
                            color: colMuted
                            Layout.alignment: Qt.AlignHCenter
                        }

                        Text {
                            text: "Type attribute value and tap Search"
                            font.pixelSize: 11
                            color: "#90A4AE"
                            Layout.alignment: Qt.AlignHCenter
                        }
                    }
                }

                // Busy Indicator
                BusyIndicator {
                    anchors.centerIn: parent
                    running: isSearching
                    visible: isSearching
                }
            }
        }
    }

    // Zoom to result helper
    function zoomToResult(res) {
        if (!res || !mapCanvas) return;
        var geomUtils = (typeof QfGeometryUtils !== "undefined") ? QfGeometryUtils : null;
        var crsUtils = (typeof CoordinateReferenceSystemUtils !== "undefined") ? CoordinateReferenceSystemUtils : null;

        var success = Engine.zoomToFeature(res.feature, res.layer, mapCanvas, activeProject, geomUtils, crsUtils);
        if (success) {
            showToast("Zoomed to " + res.title);
        } else {
            showToast("Feature has no valid geometry to zoom.");
        }
    }

    // -------------------------------------------------------------------------
    // 3. Attribute Inspector Modal Popup
    // -------------------------------------------------------------------------
    Popup {
        id: attributeInspectorPopup
        parent: rootContainer
        x: Math.max(0, (parent.width - width) / 2)
        y: Math.max(10, (parent.height - height) / 2)
        width: Math.min(parent.width - 24, 480)
        height: Math.min(parent.height - 24, 520)
        modal: true
        focus: true

        background: Rectangle {
            color: "#FFFFFF"
            radius: 14
            border.color: colPrimary
            border.width: 1
        }

        contentItem: ColumnLayout {
            spacing: 8
            anchors.fill: parent
            anchors.margins: 12

            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: selectedResultTitle
                    font.pixelSize: 15
                    font.bold: true
                    color: colTextDark
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }

                Button {
                    text: "✕"
                    flat: true
                    Layout.preferredWidth: 32
                    Layout.preferredHeight: 32
                    onClicked: attributeInspectorPopup.close()
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: "#ECEFF1"
            }

            ListView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 4
                model: Object.keys(selectedResultAttributes)

                delegate: Rectangle {
                    width: parent.width
                    height: attrRow.implicitHeight + 10
                    color: index % 2 === 0 ? "#F8F9FA" : "#FFFFFF"
                    radius: 4

                    RowLayout {
                        id: attrRow
                        anchors.fill: parent
                        anchors.margins: 6
                        spacing: 8

                        Text {
                            text: modelData
                            font.pixelSize: 11
                            font.bold: true
                            color: "#37474F"
                            Layout.preferredWidth: 120
                            elide: Text.ElideRight
                        }

                        Text {
                            text: selectedResultAttributes[modelData] || "—"
                            font.pixelSize: 11
                            color: colTextDark
                            Layout.fillWidth: true
                            wrapMode: Text.WrapAnywhere
                        }
                    }
                }
            }

            Button {
                Layout.fillWidth: true
                Layout.preferredHeight: 38
                text: "Close"
                onClicked: attributeInspectorPopup.close()
            }
        }
    }
}
