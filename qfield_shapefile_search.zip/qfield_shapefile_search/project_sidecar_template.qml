// =============================================================================
// QField Project Sidecar Search Plugin
// =============================================================================
// HOW TO USE:
// 1. Rename this file to match your QGIS project filename exactly:
//    Example: If your project is "field_survey.qgz" or "field_survey.qgs",
//             rename this file to "field_survey.qml".
// 2. Put "field_survey.qml" in the exact same directory as "field_survey.qgz".
// 3. Open the project in QField or sync it via QFieldCloud!
//    The Shapefile Search tool icon will automatically appear in your QField toolbar.
// =============================================================================

import QtQuick 2.14
import QtQuick.Controls 2.14
import QtQuick.Layouts 1.14
import org.qfield 1.0
import org.qgis 1.0

Item {
    id: sidecarRoot
    visible: true

    readonly property var mainWindow: (typeof iface !== "undefined" && iface && typeof iface.mainWindow === "function") ? iface.mainWindow() : null
    readonly property var mapCanvas: (typeof iface !== "undefined" && iface && typeof iface.mapCanvas === "function") ? iface.mapCanvas() : null
    readonly property var activeProject: (typeof qgisProject !== "undefined") ? qgisProject : null
    readonly property var rootContainer: mainWindow ? mainWindow.contentItem : sidecarRoot

    readonly property color colPrimary: (typeof Theme !== "undefined" && Theme.mainColor) ? Theme.mainColor : "#1E88E5"
    readonly property color colBg: (typeof Theme !== "undefined" && Theme.toolButtonBackgroundColor) ? Theme.toolButtonBackgroundColor : "#263238"

    property var vectorLayers: []
    property var currentFields: ["All Fields"]
    property var searchResults: []
    property bool isSearching: false
    property var selectedResultAttributes: ({})
    property string selectedResultTitle: ""

    Component.onCompleted: {
        if (typeof iface !== "undefined" && iface && typeof iface.addItemToPluginsToolbar === "function") {
            iface.addItemToPluginsToolbar(toolbarButton);
        }
        refreshLayers();
    }

    // -------------------------------------------------------------------------
    // Self-Contained Search Logic
    // -------------------------------------------------------------------------
    function isVectorLayer(layer) {
        if (!layer) return false;
        try {
            if (typeof layer.type === 'function') return layer.type() === 0;
            if (typeof layer.type !== 'undefined') return layer.type === 0 || layer.type === "VectorLayer";
            return typeof layer.getFeatures === 'function' || typeof layer.fields !== 'undefined';
        } catch (e) {
            return false;
        }
    }

    function getVectorLayers() {
        var layers = [];
        if (!activeProject) return layers;
        try {
            var mapLayers = (typeof activeProject.mapLayers === 'function') ? activeProject.mapLayers() : activeProject.mapLayers;
            if (mapLayers) {
                for (var key in mapLayers) {
                    var layer = mapLayers[key];
                    if (layer && isVectorLayer(layer)) {
                        var name = (typeof layer.name === 'function') ? layer.name() : (layer.name || key);
                        var id = (typeof layer.id === 'function') ? layer.id() : (layer.id || key);
                        layers.push({ id: id, name: name, layer: layer });
                    }
                }
            }
        } catch (e) {}
        layers.sort(function(a, b) { return a.name.localeCompare(b.name); });
        return layers;
    }

    function getLayerFields(layer) {
        var names = [];
        if (!layer) return names;
        try {
            var fields = (typeof layer.fields === 'function') ? layer.fields() : layer.fields;
            if (fields) {
                if (typeof fields.names === 'function') return fields.names();
                var count = (typeof fields.count === 'function') ? fields.count() : fields.count;
                for (var i = 0; i < count; i++) {
                    var f = (typeof fields.at === 'function') ? fields.at(i) : (typeof fields.field === 'function' ? fields.field(i) : null);
                    if (f) {
                        var fn = (typeof f.name === 'function') ? f.name() : f.name;
                        if (fn) names.push(fn);
                    }
                }
            }
        } catch (e) {}
        return names;
    }

    function refreshLayers() {
        var lyrs = getVectorLayers();
        vectorLayers = lyrs;
        var model = ["All Vector Layers (" + lyrs.length + ")"];
        for (var i = 0; i < lyrs.length; i++) model.push(lyrs[i].name);
        layerSelector.model = model;
        layerSelector.currentIndex = 0;
        updateFields();
    }

    function updateFields() {
        var fields = ["All Fields"];
        if (layerSelector.currentIndex > 0 && vectorLayers.length >= layerSelector.currentIndex) {
            var lyrObj = vectorLayers[layerSelector.currentIndex - 1];
            if (lyrObj && lyrObj.layer) {
                fields = fields.concat(getLayerFields(lyrObj.layer));
            }
        }
        currentFields = fields;
        fieldSelector.model = fields;
        fieldSelector.currentIndex = 0;
    }

    function buildFieldExpr(field, text, mode, caseSens) {
        var safeField = '"' + field.replace(/"/g, '""') + '"';
        var escaped = text.replace(/'/g, "''");

        if (mode === "range") {
            var p = text.split(",");
            if (p.length === 2) {
                var lo = parseFloat(p[0]);
                var hi = parseFloat(p[1]);
                if (!isNaN(lo) && !isNaN(hi)) return "to_real(" + safeField + ") >= " + lo + " AND to_real(" + safeField + ") <= " + hi;
            }
            return "";
        }
        if (mode === "exact") {
            var num = parseFloat(text);
            if (!isNaN(num) && ("" + num) === text) return safeField + " = " + num;
            return caseSens ? "to_string(" + safeField + ") = '" + escaped + "'" : "lower(to_string(" + safeField + ")) = lower('" + escaped + "')";
        }
        if (mode === "wildcard") {
            var pat = escaped.replace(/\*/g, "%").replace(/\?/g, "_");
            return caseSens ? "to_string(" + safeField + ") LIKE '" + pat + "'" : "to_string(" + safeField + ") ILIKE '" + pat + "'";
        }
        if (mode === "starts") {
            return caseSens ? "to_string(" + safeField + ") LIKE '" + escaped + "%'" : "to_string(" + safeField + ") ILIKE '" + escaped + "%'";
        }
        if (mode === "ends") {
            return caseSens ? "to_string(" + safeField + ") LIKE '%" + escaped + "'" : "to_string(" + safeField + ") ILIKE '%" + escaped + "'";
        }
        // contains
        return caseSens ? "to_string(" + safeField + ") LIKE '%" + escaped + "%'" : "to_string(" + safeField + ") ILIKE '%" + escaped + "%'";
    }

    function executeSearch() {
        var query = searchInput.text.trim();
        if (!query) {
            showToast("Please enter search text.");
            return;
        }

        isSearching = true;
        searchResults = [];

        var mode = modeSelector.currentValue;
        var caseSens = caseSensCheckbox.checked;
        var limit = parseInt(limitSelector.currentText) || 100;

        var targetLayers = [];
        if (layerSelector.currentIndex === 0) targetLayers = vectorLayers;
        else if (vectorLayers.length >= layerSelector.currentIndex) targetLayers = [vectorLayers[layerSelector.currentIndex - 1]];

        var results = [];
        var remaining = limit;

        for (var i = 0; i < targetLayers.length; i++) {
            if (remaining <= 0) break;
            var lyr = targetLayers[i].layer;
            var lyrName = targetLayers[i].name;
            var availFields = getLayerFields(lyr);
            var searchFields = availFields;

            if (fieldSelector.currentIndex > 0) {
                var chosen = fieldSelector.currentText;
                searchFields = availFields.filter(function(f) { return f.toLowerCase() === chosen.toLowerCase(); });
            }

            if (searchFields.length === 0) continue;

            var clauses = [];
            for (var f = 0; f < searchFields.length; f++) {
                var c = buildFieldExpr(searchFields[f], query, mode, caseSens);
                if (c) clauses.push("(" + c + ")");
            }
            if (clauses.length === 0) continue;

            var exprStr = clauses.join(" OR ");
            var it = null;

            try {
                if (typeof LayerUtils !== "undefined" && typeof LayerUtils.createFeatureIteratorFromExpression === 'function') {
                    it = LayerUtils.createFeatureIteratorFromExpression(lyr, exprStr);
                } else if (typeof lyr.getFeatures === 'function') {
                    it = lyr.getFeatures(exprStr);
                }

                if (it) {
                    while (remaining > 0) {
                        var feat = null;
                        if (typeof it.hasNext === 'function') {
                            if (!it.hasNext()) break;
                            feat = it.next();
                        } else if (typeof it.nextFeature === 'function') {
                            feat = (typeof lyr.createFeature === 'function') ? lyr.createFeature() : {};
                            if (!it.nextFeature(feat)) break;
                        } else break;

                        if (feat) {
                            var fid = (typeof feat.id === 'function') ? feat.id() : (feat.id || results.length);
                            var attrs = {};
                            for (var a = 0; a < availFields.length; a++) {
                                var fn = availFields[a];
                                var val = (typeof feat.attribute === 'function') ? feat.attribute(fn) : "";
                                attrs[fn] = (val !== null && typeof val !== 'undefined') ? ("" + val) : "";
                            }

                            var title = "FID: " + fid;
                            for (var k in attrs) {
                                if (attrs[k] && k.toLowerCase().match(/(name|label|title|code|desc|id|farm|parcel)/i)) {
                                    title = attrs[k];
                                    break;
                                }
                            }

                            results.push({
                                fid: fid,
                                layerName: lyrName,
                                layer: lyr,
                                feature: feat,
                                title: title,
                                attributes: attrs
                            });
                            remaining--;
                        }
                    }
                }
            } catch (err) {
            } finally {
                if (it && typeof it.close === 'function') {
                    try { it.close(); } catch(e) {}
                }
            }
        }

        searchResults = results;
        isSearching = false;
        showToast(results.length > 0 ? "Found " + results.length + " matching features." : "No matching features found.");
    }

    function zoomToResult(res) {
        if (!res || !mapCanvas) return;
        try {
            var geom = (typeof res.feature.geometry === 'function') ? res.feature.geometry() : res.feature.geometry;
            if (!geom || (typeof geom.isNull === 'function' && geom.isNull())) return;
            var box = (typeof geom.boundingBox === 'function') ? geom.boundingBox() : null;
            if (box && mapCanvas.mapSettings) {
                var w = (typeof box.width === 'function') ? box.width() : box.width;
                var h = (typeof box.height === 'function') ? box.height() : box.height;
                if (w === 0 && h === 0) {
                    var pt = (typeof geom.centroid === 'function') ? geom.centroid().asPoint() : null;
                    if (pt) {
                        if (typeof mapCanvas.jumpTo === 'function') mapCanvas.jumpTo(pt, 2500);
                        else mapCanvas.mapSettings.center = pt;
                        showToast("Zoomed to " + res.title);
                        return;
                    }
                }
                if (typeof mapCanvas.setExtent === 'function') mapCanvas.setExtent(box);
                else mapCanvas.mapSettings.extent = box;
                showToast("Zoomed to " + res.title);
            }
        } catch(e) {}
    }

    function showToast(msg) {
        if (mainWindow && typeof mainWindow.displayToast === "function") mainWindow.displayToast(msg);
    }

    // -------------------------------------------------------------------------
    // Toolbar Button
    // -------------------------------------------------------------------------
    QfToolButton {
        id: toolbarButton
        iconSource: Theme.getThemeVectorIcon("ic_search_white_24dp")
        iconColor: colPrimary
        bgcolor: colBg
        round: true
        visible: true
        onClicked: {
            refreshLayers();
            drawerPopup.open();
        }
    }

    // -------------------------------------------------------------------------
    // Search Drawer UI
    // -------------------------------------------------------------------------
    Popup {
        id: drawerPopup
        parent: rootContainer
        x: Math.max(0, (parent.width - width) / 2)
        y: Math.max(10, parent.height - height - 10)
        width: Math.min(parent.width - 20, 580)
        height: Math.min(parent.height - 20, 640)
        modal: true
        focus: true
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside

        background: Rectangle {
            color: "#FFFFFF"
            radius: 14
            border.color: "#B0BEC5"
            border.width: 1
        }

        contentItem: ColumnLayout {
            spacing: 8
            anchors.fill: parent
            anchors.margins: 12

            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "🔍 Project Shapefile Search"
                    font.pixelSize: 16
                    font.bold: true
                    color: "#212121"
                    Layout.fillWidth: true
                }
                Button {
                    text: "✕"
                    flat: true
                    Layout.preferredWidth: 32
                    Layout.preferredHeight: 32
                    onClicked: drawerPopup.close()
                }
            }

            RowLayout {
                Layout.fillWidth: true
                ComboBox {
                    id: layerSelector
                    Layout.fillWidth: true
                    onCurrentIndexChanged: updateFields()
                }
                ComboBox {
                    id: fieldSelector
                    Layout.fillWidth: true
                    model: currentFields
                }
            }

            RowLayout {
                Layout.fillWidth: true
                TextField {
                    id: searchInput
                    Layout.fillWidth: true
                    placeholderText: "Search value..."
                    onAccepted: executeSearch()
                }
                Button {
                    text: "Search"
                    Layout.preferredWidth: 80
                    font.bold: true
                    onClicked: executeSearch()
                }
            }

            RowLayout {
                Layout.fillWidth: true
                ComboBox {
                    id: modeSelector
                    Layout.fillWidth: true
                    textRole: "label"
                    valueRole: "mode"
                    model: [
                        { label: "Contains", mode: "contains" },
                        { label: "Exact", mode: "exact" },
                        { label: "Starts with", mode: "starts" },
                        { label: "Wildcard (*)", mode: "wildcard" },
                        { label: "Range (min,max)", mode: "range" }
                    ]
                }
                CheckBox {
                    id: caseSensCheckbox
                    text: "Match case"
                }
                ComboBox {
                    id: limitSelector
                    Layout.preferredWidth: 70
                    model: ["50", "100", "200"]
                    currentIndex: 1
                }
            }

            ListView {
                id: resList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 6
                model: searchResults

                delegate: Rectangle {
                    width: resList.width
                    height: 58
                    radius: 8
                    color: "#F5F7F8"
                    border.color: "#CFD8DC"

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 6
                        spacing: 8

                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2
                            Text {
                                text: modelData.layerName + " • FID: " + modelData.fid
                                font.pixelSize: 10
                                color: "#1E88E5"
                                font.bold: true
                            }
                            Text {
                                text: modelData.title
                                font.pixelSize: 13
                                font.bold: true
                                color: "#263238"
                                elide: Text.ElideRight
                                Layout.fillWidth: true
                            }
                        }

                        Button {
                            text: "Zoom 🔍"
                            onClicked: zoomToResult(modelData)
                        }
                    }
                }
            }
        }
    }
}
